

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;


public class TabletGUI extends JFrame {

   private JPanel contentPane;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater( new Runnable() {

         public void run() {
            try {
               TabletGUI frame = new TabletGUI();
               frame.setVisible( true );
            }
            catch (Exception e) {
               e.printStackTrace();
            }
         }
      } );
   }

   /**
    * Create the frame.
    */
   public TabletGUI() {
      setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      setBounds( 100, 100, 550, 600 );
      contentPane = new JPanel();
      contentPane.setBackground(SystemColor.infoText);
      contentPane.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );
      setContentPane( contentPane );
      contentPane.setLayout(null);
      
      
      JButton btnChest = new JButton("Chest");
      btnChest.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            TabletGUI.this.setVisible(false);
            ChestSensorGUI chestSensor = new ChestSensorGUI();
            chestSensor.setVisible(true);
         }
      });
      btnChest.setBounds(214, 165, 89, 23);
      contentPane.add(btnChest);
      
      
      JButton btnRightArm = new JButton("Right Arm");
      btnRightArm.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            TabletGUI.this.setVisible(false);
            RASensorGUI RASensor = new RASensorGUI();
            RASensor.setVisible(true);
         }
      });
      btnRightArm.setBounds(101, 231, 89, 23);
      contentPane.add(btnRightArm);
      
      
      JButton btnLeftArm = new JButton("Left Arm");
      btnLeftArm.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            TabletGUI.this.setVisible(false);
            LASensorGUI LASensor = new LASensorGUI();
            LASensor.setVisible(true);
         }
      });
      btnLeftArm.setBounds(327, 231, 89, 23);
      contentPane.add(btnLeftArm);
      
      
      JButton btnRightArm_1 = new JButton("Right Leg");
      btnRightArm_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            TabletGUI.this.setVisible(false);
            RLSensorGUI RLSensor = new RLSensorGUI();
            RLSensor.setVisible(true);
         }
      });
      btnRightArm_1.setBounds(143, 340, 89, 23);
      contentPane.add(btnRightArm_1);
      
      
      JButton btnNewButton = new JButton("Left Leg");
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            TabletGUI.this.setVisible(false);
            LLSensorGUI LLSensor = new LLSensorGUI();
            LLSensor.setVisible(true);
         }
      });
      btnNewButton.setBounds(284, 340, 89, 23);
      contentPane.add(btnNewButton);
      
      
   }

}
