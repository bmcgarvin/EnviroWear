import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.sql.*;
import javax.swing.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.EmptyBorder;

import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.SystemColor;


public class RLSensorGUI extends JFrame {

   private JPanel contentPane;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater( new Runnable() {

         public void run() {
            try {
               RLSensorGUI frame = new RLSensorGUI();
               frame.setVisible( true );
            }
            catch (Exception e) {
               e.printStackTrace();
            }
         }
      } );
   }

   /**
    * Create the frame.
    */
   public RLSensorGUI() {
      setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      setBounds( 100, 100, 550, 600 );
      contentPane = new JPanel();
      contentPane.setBackground(SystemColor.infoText);
      contentPane.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );
      contentPane.setLayout( new BorderLayout( 0, 0 ) );
      setContentPane( contentPane );
      contentPane.setLayout(null);
      
      /*
       * BUTTON TO GO BACK TO THE MAIN TABLET GUI SCREEN
       */
      JButton btnNewButton = new JButton("");
      Image img_home = new ImageIcon(this.getClass().getResource("/home.png")).getImage();
      btnNewButton.setIcon( new ImageIcon(img_home));
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            RLSensorGUI.this.setVisible(false);
            TabletGUI tablet = new TabletGUI();
            tablet.setVisible( true );
            
            
//*************************************************************************************
//          IMPLEMENT A WAY TO SAVE THE STATE UPON RETURNING TO HOME SCREEN OR TO WRITE THE INTEGER 
//          VALUE TO TEXT DOCUMENT FOR TESTING PURPOSES. USE THIS TEXT DOCUMENT TO LOAD
//          INTO TEXT FIELD OF SENSOR CLASSES UPON OPENING THEM FROM MAIN TABLET GUI
//          IF USER IS OPENING FOR THE FIRST TIME, HAVE DEFAULT TEXT DOCUMENT THAT HAS
//          HAS ALL TEXTFIELDS WITH 70 DEGREE TEMPERATURES IN THE TEXT FIELD.  
            
         }
      });
      
      
      /* 
       * TextPane to display current Temperature
       */
      JTextPane textPane = new JTextPane();
      textPane.setForeground(SystemColor.window);
      textPane.setToolTipText("");
      textPane.setText("70");
      textPane.setFont(new Font("Calibri", Font.BOLD, 18));
      textPane.setOpaque(false);
      textPane.setBounds(249, 230, 26, 36);
      contentPane.add(textPane);
      btnNewButton.setBackground(SystemColor.infoText);
      btnNewButton.setBounds(209, 433, 104, 96);
      contentPane.add(btnNewButton);
      
      
      /*
       * BUTTON TO DECREMENT THE TEMPERATURE 
       */
      JButton button = new JButton("");
      //add image into button
      Image img = new ImageIcon(this.getClass().getResource("/minus.png")).getImage();
      button.setIcon( new ImageIcon(img));
      
      //add action listener to perform task
      button.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent arg0) {
            
            //TO DO: Add logic to decrement the value in the text field by one each time the button is clicked
            // potentially saving the value in a text document for later use. 
              int value = Integer.parseInt( textPane.getText() );
              value = value - 1;
              textPane.setText(Integer.toString( value ));
            
         }
      });
      button.setBounds(65, 230, 72, 72);
      contentPane.add(button);
      
      
      /*
       * BUTTON TO INCREMENT THE TEMPERATURE  
       */
      JButton button_1 = new JButton("");
    //add image into button
      Image img_1 = new ImageIcon(this.getClass().getResource("/plus.png")).getImage();
      button_1.setIcon( new ImageIcon(img_1));
      
      button_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent arg0) {
            
          //TO DO: Add logic to increment the value in the text field by one each time we press the button
            int value = Integer.parseInt( textPane.getText() );
            value = value + 1;
            textPane.setText(Integer.toString( value ));
            
         }
      });
      button_1.setBounds(387, 230, 72, 72);
      contentPane.add(button_1);
      
      
      /*
       * POWER THE SENSOR ON
       */
       JButton pwr_on = new JButton("");
       pwr_on.setBorderPainted(false);
       pwr_on.setBackground(SystemColor.infoText);
     //add image into button
       Image power_on = new ImageIcon(this.getClass().getResource("/power-off.png")).getImage();
       pwr_on.setIcon( new ImageIcon(power_on));
       
       //add action listener to perform task of turning sensor on
       pwr_on.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
             
             //when we click the button it turns green to indicate we turned the power on, two jbuttons overlayed 
             //set this button to false so the green button appears.
             pwr_on.setVisible( false );
             
             
             
             //TO DO: add method call to turn sensor on, the sensor should start by being off.
             
             
             
          }
       });
       pwr_on.setBounds(249, 346, 26, 23);
       contentPane.add(pwr_on);
       
      /*
       * POWER THE SENSOR OFF 
       */
       JButton pwr_off = new JButton("");
       pwr_off.setBorderPainted(false);
       pwr_off.setBackground(SystemColor.infoText);
       //add image into button
         Image power_off = new ImageIcon(this.getClass().getResource("/power-on.png")).getImage();
         pwr_off.setIcon( new ImageIcon(power_off));
         
         //add action listener to perform task of turning sensor off
         pwr_off.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               
             //when we click the button it turns red to indicate we shut the power off
               
               pwr_on.setVisible( true );
               
               
               //TO DO: add method call to turn sensor off
               
               
            }
         });
         pwr_off.setBounds(249, 346, 26, 23);
         contentPane.add(pwr_off);
         
         JLabel lblNewLabel = new JLabel("");
         //Set image in background for thermostat screen
         Image label = new ImageIcon(this.getClass().getResource("/thermo.png")).getImage();
         lblNewLabel.setIcon( new ImageIcon(label));
         lblNewLabel.setBounds(197, 166, 134, 167);
         contentPane.add(lblNewLabel);
   
   }

}
